# La Vallée des Anges — Complete Setup Guide

Project: https://tpqsuwnvonzjvjofhoiq.supabase.co

---

## Step 1 — Create the database table

1. Go to https://supabase.com → open your project
2. Click **SQL Editor** in the left sidebar
3. Click **New query**
4. Open `supabase-schema.sql`, copy the entire file, paste it, and click **Run**
5. You should see green output: "Table created: reservations" and a column list

---

## Step 2 — Create your admin login

The admin dashboard (`admin.html`) is protected by a real login screen.

1. In Supabase, go to **Authentication → Users**
2. Click **Add user → Create new user**
3. Enter an email (this is your admin username) and a strong password
4. Click **Create user**

That email + password is what you use to log into `admin.html`.

---

## Step 3 — Deploy the files

Upload these files to any static web host (Netlify, Vercel, GitHub Pages, your own server):

| File                  | Purpose                                    |
|-----------------------|--------------------------------------------|
| `index.html`          | Main website with reservation form         |
| `admin.html`          | Admin dashboard (protected by login)       |
| `supabase-schema.sql` | Database setup (run once in SQL Editor)    |

No server or build step required — these are plain HTML/CSS/JS files.

### Netlify (fastest option)
1. Go to https://app.netlify.com
2. Drag and drop both HTML files onto the Netlify drop zone
3. Done — you'll get a live URL immediately

### GitHub Pages
1. Push both files to a GitHub repository
2. Go to Settings → Pages → Deploy from main branch
3. Your site will be live at `https://username.github.io/repo-name`

---

## Step 4 — Test the reservation form

1. Open `index.html` in a browser
2. Click **Reserve a table**
3. Fill in all required fields and click **Submit Reservation**
4. You should see: "Your reservation has been successfully received."
5. In Supabase, go to **Table Editor → reservations** — your row should appear

---

## Step 5 — Use the admin dashboard

1. Open `admin.html` in a browser
2. Sign in with the email/password from Step 2
3. All reservations appear sorted by date and time
4. **Search** — type a name or phone number to filter instantly
5. **Edit** — click "Edit", change fields inline, click "Save"
6. **Delete** — click "Delete" and confirm the prompt
7. **Log out** — click "Log out" in the top-right corner

---

## Security checklist

- [x] Anon key can only INSERT (public form) — cannot read or modify data
- [x] Admin read/edit/delete requires Supabase Auth login
- [x] Row Level Security (RLS) is enabled on the reservations table
- [ ] Keep `admin.html` unlinked from the public website navigation
- [ ] After testing, regenerate your anon key in Supabase → Project Settings → API
      (since it appeared in this conversation)

---

## Troubleshooting

**Form submits but nothing saves**
→ Check browser console (F12) for errors. Most common: RLS policy missing.
   Re-run the SQL schema to recreate policies.

**Admin dashboard shows empty after login**
→ Confirm you created a user under Authentication → Users (not just a database user).

**"Invalid login credentials" on admin page**
→ The email/password must match a user under Authentication → Users, not a database record.

**CORS errors in console**
→ This happens when opening HTML files directly from your desktop (file:// protocol).
   Always open via a web server (localhost or deployed URL).

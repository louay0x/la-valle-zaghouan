-- ================================================================
-- La Vallée des Anges — Supabase Database Setup
-- Project: https://tpqsuwnvonzjvjofhoiq.supabase.co
--
-- HOW TO RUN:
--   1. Open your Supabase project dashboard
--   2. Go to SQL Editor (left sidebar)
--   3. Click "New query"
--   4. Paste this entire file and click "Run"
-- ================================================================

-- Enable UUID generation
create extension if not exists "uuid-ossp";

-- ----------------------------------------------------------------
-- Drop existing table if re-running (safe to run multiple times)
-- ----------------------------------------------------------------
drop table if exists public.reservations;

-- ----------------------------------------------------------------
-- Reservations table
-- ----------------------------------------------------------------
create table public.reservations (
  id                uuid         primary key default uuid_generate_v4(),
  first_name        text         not null check (char_length(first_name) > 0),
  last_name         text         not null check (char_length(last_name) > 0),
  phone             text         not null check (char_length(phone) >= 6),
  table_number      integer      not null check (table_number > 0),
  guests            integer      not null check (guests > 0),
  reservation_date  date         not null,
  reservation_time  time         not null,
  notes             text,
  created_at        timestamptz  not null default now()
);

-- Performance indexes
create index reservations_date_idx   on public.reservations (reservation_date, reservation_time);
create index reservations_search_idx on public.reservations (lower(last_name), lower(first_name), phone);

-- ----------------------------------------------------------------
-- Row Level Security
-- ----------------------------------------------------------------
alter table public.reservations enable row level security;

-- PUBLIC: anyone with the anon key can INSERT (the reservation form)
create policy "anon_insert"
  on public.reservations
  for insert
  to anon
  with check (true);

-- AUTHENTICATED (admin dashboard login): full read / update / delete
create policy "auth_select"
  on public.reservations
  for select
  to authenticated
  using (true);

create policy "auth_update"
  on public.reservations
  for update
  to authenticated
  using (true)
  with check (true);

create policy "auth_delete"
  on public.reservations
  for delete
  to authenticated
  using (true);

-- ----------------------------------------------------------------
-- Verify setup (optional — check output in SQL Editor)
-- ----------------------------------------------------------------
select 'Table created: reservations' as status;
select column_name, data_type, is_nullable
  from information_schema.columns
  where table_schema = 'public' and table_name = 'reservations'
  order by ordinal_position;
